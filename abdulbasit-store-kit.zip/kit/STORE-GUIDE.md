# Publishing Abdul Basit Quran on Google Play and the App Store

| Folder | What it is |
|---|---|
| `1-website` | The app as a website. Put this online first; Android uses it directly. Includes the privacy policy. |
| `2-ios-app` | Ready-to-build iPhone/iPad project (Capacitor). Needs a Mac. |
| `3-android-app` | Step-by-step guide to make the Google Play app from your website (no coding). |
| `4-store-listing` | Store icons, Play feature graphic, and listing text in English and Arabic. |

## Costs
- Google Play: US$25 once.  Apple App Store: US$99 per year.  Everything else is free.

## Step 1 — Put the website online (both stores need it)
Upload everything in `1-website` (including `privacy.html` and the hidden `.nojekyll` file) to your
GitHub repository `abdulbasit`, replacing the old files. Check that these open:
- `https://YOUR-USERNAME.github.io/abdulbasit/`
- `https://YOUR-USERNAME.github.io/abdulbasit/privacy.html`

Edit `privacy.html` first: replace **YOUR-EMAIL-HERE** with a contact email (both stores require one).

## Step 2 — Android
Follow `3-android-app/README.md`. Can be done entirely from a phone.

## Step 3 — iPhone
Follow `2-ios-app/README.md`. Requires a Mac (or a rented cloud Mac).

## Things reviewers may ask about
- **Rights to the recordings.** The audio is streamed from public Islamic audio services and
  Internet Archive uploads; the app does not host it. Apple (guideline 5.2) and Google can ask you
  to show you're allowed to offer downloads of third-party audio. If asked, explain the sources
  (listed in Settings → Sources). To be extra safe for review, you can hide the Download button for
  Internet Archive recordings — ask and I'll add a setting for it.
- **Apple "minimum functionality" (4.2).** The app works offline, plays in the background with
  lock-screen controls, and has downloads, favourites and playlists — mention these in the review
  notes.
- **Google Play testing rule.** New personal accounts need a closed test with 12 testers for
  14 days before going public.
