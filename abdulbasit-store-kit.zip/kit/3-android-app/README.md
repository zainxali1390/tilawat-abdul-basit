# Android app for Google Play (Trusted Web Activity)

The Android app runs your website (folder 1-website) inside Chrome's engine, full screen
with no address bar. This keeps background playback and lock-screen controls working exactly
as they do in Chrome.

## Before you start
- The website must be online at an https address (see STORE-GUIDE.md, step 1).
- A Google Play developer account (one-time US$25).

## Build the app (no coding, works from a phone browser)
1. Go to **pwabuilder.com** and enter your app's address, e.g. `https://YOUR-USERNAME.github.io/abdulbasit/`.
2. Tap **Package For Stores** → **Android** → **Generate Package**.
   - Package ID: `com.abdulbasit.quranapp` (or your own; it can never be changed after publishing)
   - App name: Abdul Basit Quran · Launcher name: Abdul Basit
   - Keep "Signing key: Create new".
3. Download the zip. Inside you'll find:
   - `*.aab` — the file you upload to Google Play
   - `*.apk` — install this on your own phone to test
   - `signing.keystore` and `signing-key-info.txt` — **keep both safe forever**. Every future
     update must be signed with them.
   - `assetlinks.json` — needed in the next step.

## Remove the address bar (Digital Asset Links)
Android only hides the address bar when your site proves it owns the app. The proof file must be
at the **root** of your domain: `https://YOUR-USERNAME.github.io/.well-known/assetlinks.json`

1. On GitHub create a second public repository named exactly `YOUR-USERNAME.github.io`.
2. Upload an empty file named `.nojekyll` and the `assetlinks.json` from PWABuilder into a
   folder called `.well-known` (when uploading, type `.well-known/assetlinks.json` as the file name).
3. Turn on Pages for that repository (Settings → Pages → main → / root).
4. After you upload the app to Play, open Play Console → your app → **Setup → App signing**,
   copy the **SHA-256 certificate fingerprint** of the *App signing key*, and add it to the
   `sha256_cert_fingerprints` list in `assetlinks.json` (keep the one already there). Re-upload.

## Upload to Google Play
1. Play Console → **Create app** → name, default language, App, Free.
2. Fill in **App content**: privacy policy URL (`.../abdulbasit/privacy.html`), Ads: No,
   Data safety: no data collected or shared, target audience, content rating questionnaire.
3. **Store listing**: use the text and images in `4-store-listing`, plus at least 2 phone screenshots
   (take them on your phone from the installed app).
4. **Testing → Internal testing** → create release → upload the `.aab` → test on your phone.
5. New personal developer accounts must run a **closed test with at least 12 testers for 14 days**
   before production is unlocked. Then **Production → Create release** → upload → send for review.

## Updating later
Upload new files to the website; the app picks them up automatically. You only need a new `.aab`
(from PWABuilder, using the same signing key) to change the app's name, icon or package settings.
