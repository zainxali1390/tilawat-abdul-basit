# iOS app for the App Store (Capacitor)

The app files are bundled inside the iPhone app (folder `www`), so it opens without
internet; recitations still stream from their servers or play from downloads.

## You need
- A **Mac** with **Xcode** (free from the Mac App Store). Apple only allows iOS apps to be built
  on a Mac. If you don't have one, a cloud Mac rental (e.g. MacinCloud) works.
- **Node.js** (nodejs.org, LTS version).
- An **Apple Developer Program** membership (US$99/year) to publish.

## Build
In Terminal, inside this folder:
```
npm install
npm run setup:ios
npm run open:ios
```
`setup:ios` creates the Xcode project and turns on background audio (so recitations keep playing
with the screen locked, with lock-screen controls).

In Xcode:
1. Click **App** in the left sidebar → **Signing & Capabilities** → Team: choose your Apple
   Developer account. Bundle Identifier: `com.abdulbasit.quranapp` (or your own).
2. **App icon**: open `App/Assets.xcassets/AppIcon` and drop in `4-store-listing/app-icon-1024.png`.
3. Plug in your iPhone, choose it at the top, press ▶ to test.
4. To publish: **Product → Archive** → **Distribute App** → **App Store Connect** → Upload.

## App Store Connect
1. appstoreconnect.apple.com → **My Apps → +** → New App (iOS, name, primary language,
   the same bundle ID, an SKU such as `abdulbasit001`).
2. Fill in the listing from `4-store-listing/LISTING-TEXT.md`, upload screenshots (6.9" and
   6.5" iPhone sizes; take them in the Xcode simulator with ⌘S), privacy policy URL,
   App Privacy: **Data Not Collected**, age rating 4+.
3. Choose the build you uploaded and **Submit for Review**.

## Updating the app
Replace the files in `www` with the new ones, then run `npm run sync`, increase the version in
Xcode (General → Version/Build), archive and upload again.

## If background audio doesn't work
Check `ios/App/App/Info.plist` contains `UIBackgroundModes` → `audio`, and that
`AppDelegate.swift` has, inside `didFinishLaunchingWithOptions`:
```swift
try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
```
(with `import AVFoundation` at the top). `scripts/patch-ios.js` adds both automatically.
