/* Run once after `npx cap add ios`. Lets recitations keep playing with the screen locked
   or the app in the background, and shows lock-screen controls:
   1. Info.plist: UIBackgroundModes = audio
   2. AppDelegate.swift: set the audio session category to .playback */
const fs = require('fs');
const path = require('path');
const appDir = path.join(__dirname, '..', 'ios', 'App', 'App');

const plistPath = path.join(appDir, 'Info.plist');
let plist = fs.readFileSync(plistPath, 'utf8');
if (!plist.includes('UIBackgroundModes')) {
  const i = plist.lastIndexOf('</dict>');
  plist = plist.slice(0, i) + '\t<key>UIBackgroundModes</key>\n\t<array>\n\t\t<string>audio</string>\n\t</array>\n' + plist.slice(i);
  fs.writeFileSync(plistPath, plist);
  console.log('Info.plist: background audio enabled');
} else console.log('Info.plist: already has UIBackgroundModes');

const delegatePath = path.join(appDir, 'AppDelegate.swift');
let src = fs.readFileSync(delegatePath, 'utf8');
if (!src.includes('AVAudioSession')) {
  src = src.replace(/import UIKit/, 'import UIKit\nimport AVFoundation');
  const m = src.match(/didFinishLaunchingWithOptions[^{]*\{/);
  if (!m) { console.error('Could not find didFinishLaunchingWithOptions in AppDelegate.swift — add the audio session line by hand (see README).'); process.exit(1); }
  const at = m.index + m[0].length;
  src = src.slice(0, at) + '\n        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)\n        try? AVAudioSession.sharedInstance().setActive(true)' + src.slice(at);
  fs.writeFileSync(delegatePath, src);
  console.log('AppDelegate.swift: audio session set to playback');
} else console.log('AppDelegate.swift: already configured');
