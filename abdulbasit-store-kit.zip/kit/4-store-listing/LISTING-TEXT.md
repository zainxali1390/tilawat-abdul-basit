# Store listing text (copy and paste)

## Google Play

**App name (30 max):** Abdul Basit Quran
**Short description (80 max):** The Qur'an recited by Sheikh Abdul Basit, with Arabic text and translation.

**Full description:**
Listen to the complete Qur'an in the voice of Sheikh Abdul Basit ʿAbd as-Samad (1927–1988) and read along in the Uthmani script with English translation.

• Murattal and Mujawwad, ayah by ayah — the ayah being recited is highlighted and followed on screen
• Complete khatmas, including Murattal, Mujawwad and Warsh
• Arbaʿ recordings: Khatmat al-Arbaʿ (the first Mujawwad khatma, late 1950s–early 1960s) and the Murattal and Mujawwad mushafs in all 240 quarters
• Historical recordings: Syrian, Kuwaiti and Egyptian radio, concerts and rare recitations
• Mushaf view and translation view, by surah, juz, page or quarter
• Repeat an ayah or a range, playback speed, sleep timer
• Lock-screen controls and background playback
• Download recitations and the full text for offline use
• Favourites, playlists, and resume where you left off
• Light and dark themes, English and Arabic interface, choice of Qur'an fonts

Free, with no ads, no accounts and no tracking.

**Category:** Books & Reference (or Education)
**Contains ads:** No  **In-app purchases:** No
**Data safety:** No data collected, no data shared.
**Content rating:** Everyone

## Apple App Store

**Name (30 max):** Abdul Basit Quran
**Subtitle (30 max):** Recitation, Mushaf, Translation
**Keywords (100 max):** quran,koran,abdul basit,abdulbasit,recitation,murattal,mujawwad,mushaf,tajweed,islam,khatma
**Promotional text:** The Qur'an in the voice of Sheikh Abdul Basit, with the ayah being recited highlighted as you listen.
**Description:** use the Google Play full description above.
**Category:** Reference (secondary: Education)
**Age rating:** 4+
**App Privacy:** Data Not Collected
**Privacy Policy URL:** https://YOUR-USERNAME.github.io/abdulbasit/privacy.html

---

## العربية

**الاسم:** قرآن عبد الباسط
**وصف قصير:** القرآن الكريم بصوت الشيخ عبد الباسط عبد الصمد مع النص والترجمة.

**الوصف الكامل:**
استمع إلى القرآن الكريم كاملًا بصوت الشيخ عبد الباسط عبد الصمد (١٩٢٧–١٩٨٨) واقرأ معه بالرسم العثماني مع الترجمة الإنجليزية.

• المرتل والمجود آيةً آية، مع تظليل الآية المتلوّة ومتابعتها على الشاشة
• ختمات كاملة: مرتل ومجود وورش
• تسجيلات الأرباع: ختمة الأرباع (الختمة المجودة الأولى) والمصحفان المرتل والمجود مقسمين إلى ٢٤٠ ربعًا
• تسجيلات تاريخية: إذاعات سوريا والكويت ومصر، والحفلات، والتلاوات النادرة
• عرض المصحف أو مع الترجمة، بالسورة أو الجزء أو الصفحة أو الربع
• تكرار آية أو مقطع، وسرعة التشغيل، ومؤقت النوم
• التحكم من شاشة القفل والتشغيل في الخلفية
• تنزيل التلاوات والنص للاستخدام دون اتصال
• المفضلة وقوائم التشغيل ومتابعة الاستماع من حيث توقفت
• سمة فاتحة وداكنة، وواجهة عربية وإنجليزية، واختيار خط المصحف

مجاني، بلا إعلانات ولا حسابات ولا تتبع.
